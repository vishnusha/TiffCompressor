﻿using System.Drawing;
using System.Drawing.Imaging;

namespace TiffCompres
{
    class Program
    {
        static void Main(string[] args)
        {
            string inputPath = "C:\\Users\\vishnu\\Downloads\\Tiff-Image-File-Download.tiff";
            string outputPath = "C:\\Users\\vishnu\\Downloads\\compressed_output5555.tiff";


            try
            {
                CompressTiffToJpeg(inputPath, outputPath, 50L);
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error: " + ex.Message);
            }

            Console.WriteLine("Done. Press any key to exit.");
            Console.ReadKey();
        }

        public static void CompressTiffToJpeg(string inputPath, string outputPath, long quality = 50L)
        {
            using (Image image = Image.FromFile(inputPath))
            {
                ImageCodecInfo jpegCodec = GetEncoder(ImageFormat.Jpeg);
                if (jpegCodec == null)
                    throw new Exception("JPEG encoder not found");

                EncoderParameters encoderParams = new EncoderParameters(1);
                encoderParams.Param[0] = new EncoderParameter(System.Drawing.Imaging.Encoder.Quality, quality);

                image.Save(outputPath, jpegCodec, encoderParams);

                long originalSize = new FileInfo(inputPath).Length;
                long newSize = new FileInfo(outputPath).Length;

                Console.WriteLine($"Original size: {originalSize / 1024.0:F2} KB");
                Console.WriteLine($"Compressed size: {newSize / 1024.0:F2} KB");
                Console.WriteLine($"Size reduction: {(1 - (double)newSize / originalSize) * 100:F2}%");
            }
        }

        private static ImageCodecInfo GetEncoder(ImageFormat format)
        {
            ImageCodecInfo[] codecs = ImageCodecInfo.GetImageDecoders();
            foreach (var codec in codecs)
            {
                if (codec.FormatID == format.Guid)
                    return codec;
            }
            return null;
        }
    }

}
